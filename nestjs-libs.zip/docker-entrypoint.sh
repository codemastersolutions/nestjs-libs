#!/bin/sh

cd /app && \
pnpm start:dev
