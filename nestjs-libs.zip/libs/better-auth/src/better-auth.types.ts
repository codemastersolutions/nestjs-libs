export interface BetterAuthOptions {
  apiKey: string;
}
