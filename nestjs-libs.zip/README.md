# Nestjs Libs

Nestjs Libs is a collection of libraries that can be used in Nestjs projects.

## Libraries

- [Better Auth](https://github.com/codemastersolutions/nestjs-libs/tree/main/libs/better-auth) - A library that provides authentication and authorization features for Nestjs projects using [**_Better-Auth_**](https://www.better-auth.com/) library.
